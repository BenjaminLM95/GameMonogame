﻿
using var game = new GameMonogame.GameManager();
game.Run();
